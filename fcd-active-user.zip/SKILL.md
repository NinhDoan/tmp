---
name: fcd-active-users
description: Tổng hợp mức active của FCD theo ngày trên các cụm FCI, FIM, FSO, Customer từ VictoriaMetrics (MCP mcp-victoriametrics), dựa trên metric RemoteFX của VD. Cả tử số và mẫu số đều tính theo MÁY (VD): tử số = VD active ≥N giờ, mẫu số = tổng máy đã cấp phát (service discovery windows-exporter). KHÔNG dedupe theo owner. Dùng khi cần báo cáo active theo ngày/tuần, tỷ lệ active trên tổng máy, hoặc breakdown theo project/pool.
---

# FCD Active Users — quy trình tổng hợp

Đếm số **VD active ≥ N giờ/ngày** trên **tổng số máy (VD) đã cấp phát**, theo từng cụm **FCI / FIM / FSO / Customer**, bằng dữ liệu VictoriaMetrics (MCP server `mcp-victoriametrics`, load tool `query`, `series`, `metrics`, `label_values` qua ToolSearch).

## Định nghĩa (đã chốt với user)

- **Active** = VD đang có metric RemoteFX (`windows_remote_fx_*`) — có metric tức là user đang kết nối RDP. KHÔNG dùng `fcd_user_service_is_active` làm nguồn chính (broker đánh dấu "in use" cả khi session disconnected — trên FSO lệch +15–20 user/ngày so với RemoteFX).
- **Tử số = số MÁY (VD) active**, đếm distinct `vmid`. **KHÔNG dedupe theo `owner`** (đã chốt 02/10/2026): tử số và mẫu số phải cùng đơn vị máy, và join `owner` chỉ làm query đắt thêm một tầng `count by (owner, …)` vô ích. Đo 28/09–02/10: chênh giữa hai cách chỉ 1–8 máy mỗi ô (FCI 430 vs 429 owner, FSO 01/10 106 vs 98) vì gần như 1 VD/1 user. `fcd_user_service_info` vẫn cần, nhưng chỉ để map `vmid` → broker/project.
- Nếu user hỏi riêng **số người** thì mới bọc thêm `count by (owner, …)` — xem mục 2b, và nói rõ đó là cột phụ.
- **Mẫu số = TỔNG MÁY đã cấp phát** (đã chốt 21/09/2026, user muốn con số này chứ KHÔNG phải số user): đếm target service discovery của windows-exporter — xem mục 2. Trước 21/09 skill này lấy mẫu số là distinct owner nên FSO chỉ ra ~285 thay vì 448, nhìn thiếu ~1/3. Nếu cần thêm số user thì đưa ở cột phụ, đừng thay mẫu số. Trừ 6 máy template `vmid=""` — xem mục 2c.
- **Ngưỡng mặc định**: 4h/ngày. Nếu user không nói gì khác thì dùng 4h.
- **Múi giờ**: +07:00. Một "ngày" = cửa sổ `[24h]` đánh giá tại 00:00 (+07) của ngày hôm sau.

## Metric & mapping

| Metric | Vai trò | Label chính |
|---|---|---|
| `windows_remote_fx_net_current_tcp_rtt_seconds` | Hiện diện = đang kết nối. Scrape **60s = 60 mẫu/giờ cho cả 4 cụm** kể từ **13/10/2026 13:17 ICT** (gitops MR !92). **Dữ liệu trước mốc đó: FSO và Customer 2 phút/mẫu = 30 mẫu/giờ** (verified 26/08, 04/09, 18/09/2026) ⇒ báo cáo ngày cũ phải đổi ngưỡng, xem bảng dưới | `vmid`, `instance` (IP VD:9182), `session_name`, `cluster`, `job` |
| `fcd_user_service_info` | Map `vmid` → `owner`, `project_id`, `pool`, `ip` | `vmid`, `owner`, `project_id`, `instance` (broker) |
| `fcd_user_service_is_active` | Gauge 0/1 theo broker — chỉ dùng để đối chiếu | `vmid`, `project_id`, `instance` |
| `fcd_service_project_metadata` | Map `id` (project_id) → `name` (tên project) | `id`, `name`, `instance` |

### Ngưỡng N giờ — phụ thuộc NGÀY báo cáo, không còn phụ thuộc cụm

| Ngày báo cáo | FCI / FIM | FSO | Customer |
|---|---|---|---|
| **≥ 14/10/2026** | N × 60 | N × 60 | N × 60 |
| 13/10/2026 (ngày cutover) | N × 60 | mixed → dùng N × 30 | mixed → dùng N × 30 |
| ≤ 12/10/2026 | N × 60 | N × 30 | N × 30 |

4h ⇒ 240 mẫu (60s/mẫu) hoặc 120 mẫu (120s/mẫu).

Mốc cutover: gitops MR !92 merge 13/10/2026 06:16 UTC, ArgoCD + VM operator áp xong lúc **06:17:28 UTC = 13:17 ICT** — `VMScrapeConfig/windows-exporter-scrape-{customer,fso}` đổi `interval: 300s` → `60s`. (300s trước đó bị `maxScrapeInterval: 120s` của VMAgent cắt về 120s, nên interval thật là 2 phút chứ không phải 5 phút.)

**Ngày 13/10/2026** có 13,3h đầu ở 120s + 10,7h sau ở 60s ⇒ một VD active N giờ sinh ra từ N×30 đến N×60 mẫu tuỳ phiên nằm bên nào. Dùng **N × 30** cho FSO/Customer ngày đó (lệch về phía không bỏ sót máy active) và ghi chú rõ là xấp xỉ. Tuần/kỳ gộp bắc qua 13/10 cũng vậy.

**Luôn verify trước khi chạy** — group theo `job`, KHÔNG theo `cluster`: Customer nằm trong `cluster="fcd-fpt"` nên group theo cluster không bao giờ thấy nó (chính là lý do cột Customer bị áp sai ngưỡng suốt thời gian trước).

```promql
max by (job) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[1h]))
```

Kỳ vọng **60** cho cả `windows-exporter`, `windows-exporter-fso`, `windows-exporter-customer`; job nào không có phiên RDP nào trong giờ đó thì vắng mặt (Customer hay vắng — bình thường). Ra 30 ⇒ đang đọc vùng dữ liệu trước cutover, đổi ngưỡng theo bảng. (Đừng dùng `topk(5, …)` không group: nó chỉ hiện job đông nhất.)

**Bài học 18/09/2026:** các lần chạy trước áp 240 cho cả FSO ⇒ FSO bị đếm theo ngưỡng 8h, thiếu ~20–30% user (vd 14/09: 80 thay vì 102). Cột **Customer** của mọi bảng ≤ 12/10 cũng chạy ngưỡng gấp đôi vì bị gộp vào query chung — đã kiểm lại: các số 0 đó KHÔNG do ngưỡng (06/10 máy customer nhiều mẫu nhất chỉ 38 mẫu = 1,3h), nên bảng cũ vẫn đúng.

### Phân cụm theo broker (`instance`) — KHÔNG hard-code project list

`fcd_user_service_info` chỉ tồn tại trên đúng 3 broker, nên lọc theo `instance` là đủ và **không bao giờ sót project mới**. Đây là bài học từ 04/09/2026: cách cũ lọc bằng regex project cứng đã âm thầm bỏ sót FCI-CLOUD-HCM02-VPC (14 VD), IAAS-HAN-OSP-VPC (2 VD) và 10 bản ghi `project_id="None"` trên broker FSO.

| Cụm | Điều kiện |
|---|---|
| **FIM** | `instance="fci.fcd.fptcloud.com:443"` VÀ `project_id="edee0969aeab41e8b1cef7229086eb98"` |
| **FCI** | `instance="fci.fcd.fptcloud.com:443"`, mọi `project_id` còn lại |
| **FSO** | `instance="fcd.fsoft.com.vn:443"` |
| **Customer** | `instance="customer.fcd.fptcloud.com:443"` |

Phân cụm phải theo `instance` TRƯỚC rồi mới đến `project_id` — cùng một project_id xuất hiện trên nhiều broker (`268dbeb2…` FCI-CLOUD-HCM10-VPC có trên cả fci lẫn customer; `1cf677a8…` IAAS-HAN-OSP-VPC có trên cả 3).

Term join dùng trong mọi query (gọi là `<INFO_JOIN>`) — không filter gì cả:

```
last_over_time(fcd_user_service_info[24h])
```

Khi đếm **user** (tử số, hoặc mẫu số phụ) thì thêm `{owner!="None"}` để loại VD còn trong pool — xem mục 2b. Khi chỉ map `vmid`→project/broker thì không cần.

Bảng dưới chỉ để **tra tên**, KHÔNG dùng làm bộ lọc (snapshot 04/09/2026, số = VD):

| broker | project_id | tên | VD |
|---|---|---|---|
| fci | `2996cd47…` | FCI-CLOUD-DESKTOP | 456 |
| fci | `477d2c3e…` | FCI-CLOUD-VHHL-VPC | 167 |
| fci | `f7a48e99…` | FCI-AI-VHHL-VPC | 147 |
| fci | `268dbeb2…` | FCI-CLOUD-HCM10-VPC | 115 |
| fci | `edee0969…` | FIM-HNI1-FCD-PROD → cụm **FIM** | 76 |
| fci | `04cae87b…` | FCI-CLOUD-HCM02-VPC | 14 |
| fci | `efc09049…` | FCI-AI-HCM10-VPC | 11 |
| fsoft | `09c11aaa…` | FSO-WZ-InZ-FCD-VD | 376 |
| fsoft | `None` | (bản ghi thiếu project_id) | 10 |
| fsoft | `1cf677a8…` | IAAS-HAN-OSP-VPC | 2 |
| customer | `2096fb01…` | CUSTOMER-TEST-HAN | 10 |
| customer | `268dbeb2…` | FCI-CLOUD-HCM10-VPC (đăng ký trên broker customer) | 3 |
| customer | `adc30ebe…` | VPBankS-FCD-VPC | 2 |
| customer | `9d68e0d8…` | MMVN-FCD-ORG | 2 |
| customer | `0a14d0b4…` `c128c280…` `None` | TBM / METUB / (thiếu) | 1 mỗi cái |

Dựng lại bảng khi cần: `count by (instance, project_id) (last_over_time(fcd_user_service_info[24h]))`, rồi map tên qua `fcd_service_project_metadata{id="<pid>"}`.

Ghi chú Customer: RemoteFX phía customer CÓ label `vmid` (verified 27/08/2026) nên join hoạt động bình thường; một số bản ghi info trên broker customer/FSO **không có label `vmid`** (session troubleshoot trên template) — chỉ vào được mẫu số, không đếm active được. Quy mô hoạt động customer rất thấp (2 VD có RDP trong 7 ngày tính đến 27/08).

## Query

### 1. Số VD active ≥ N giờ cho 1 ngày

Instant query, `time` = `<NGÀY+1>T00:00:00+07:00`, ngưỡng `<N*60>`. Tách FIM khỏi FCI ngay trong query bằng `label_replace` nên **một call ra đủ cả 4 cụm** (fci, fci+FIM, fsoft, customer):

```promql
count by (instance, fim) (
  (sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[24h])) >= <N*60>)
  * on(vmid) group_left(instance, fim)
    label_replace(topk by (vmid) (1, <INFO_JOIN>),
                  "fim", "FIM", "project_id", "edee0969aeab41e8b1cef7229086eb98")
)
```

`label_replace` gắn `fim="FIM"` chỉ cho project FIM, còn lại `fim=""` ⇒ dòng `{instance="fci…"}` là FCI, dòng `{instance="fci…", fim="FIM"}` là FIM. `instance` ở đây là broker, group_left từ info.

**Ngày ≥ 14/10/2026: một call là đủ** — cả 4 cụm cùng ngưỡng `<N*60>`, không phải tách FSO ra nữa (trước 13/10 phải tách vì FSO/Customer 2 phút/mẫu).

**Ngày ≤ 12/10/2026, và mọi kỳ bắc qua 13/10: FSO + Customer phải chạy tách** với ngưỡng `<N*30>`. Lọc metric RemoteFX theo `job` (không dùng `cluster` — Customer mang `cluster="fcd-fpt"`), và ở query chung trên thì bỏ hai dòng `fcd.fsoft.com.vn:443` + `customer.fcd.fptcloud.com:443` đi (chúng đang bị đếm theo ngưỡng gấp đôi). Ví dụ 4h:

```promql
count by (instance) (
  (sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds{job=~"windows-exporter-(fso|customer)"}[24h])) >= 120)
  * on(vmid) group_left(instance) topk by (vmid) (1, last_over_time(fcd_user_service_info{instance=~"fcd\\.fsoft\\.com\\.vn:443|customer\\.fcd\\.fptcloud\\.com:443"}[24h]))
)
```

Khi đó chạy song song 2 call/ngày.

**Breakdown theo project** (chỉ khi user hỏi): đổi `count by (instance, fim)` thành `count by (instance, project_id)` và thêm `project_id` vào `group_left`. Đếm theo `vmid` nên tổng các project khớp đúng tổng cụm — chỉ cách dedupe theo `owner` mới làm tổng project lớn hơn tổng cụm (user có VD ở 2 project).

**Ngày chưa kết thúc** (hôm nay): `time` = hiện tại, window = `[<số phút từ 00:00>m]` cho cả 2 metric, ngưỡng lấy theo bảng ngưỡng ở trên (từ 14/10/2026: `<N*60>` cho cả 4 cụm); ghi chú rõ trong kết quả là ngày chưa trọn.

**Gộp cả tuần** — VD chạm mốc ≥N giờ ở ít nhất một trong các ngày trọn. **Dùng union `or` với `@` ở đúng mốc nửa đêm ICT, KHÔNG dùng subquery `[Dd:1d]`** (lý do ngay dưới). Mỗi vế là một phép *lọc* (`>=` không có `bool`) nên chỉ còn vmid active, `or` giữa chúng chính là phép hợp:

```promql
count by (instance, fim) (
  (
    (sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[24h] @ <ts_ngày1>)) >= <thr_ngày1>)
    or (sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[24h] @ <ts_ngày2>)) >= <thr_ngày2>)
    or ...
  )
  * on(vmid) group_left(instance, fim)
    label_replace(topk by (vmid) (1, <INFO_JOIN>), "fim", "FIM", "project_id", "edee0969aeab41e8b1cef7229086eb98")
)
```

`<ts_ngàyX>` = epoch của **00:00 (+07) ngày hôm sau** ngày cần đo (`date -d '2026-10-13 00:00:00 +0700' +%s`). Ưu điểm phụ: ngưỡng đặt riêng từng ngày nên kỳ bắc qua mốc cutover 13/10/2026 chạy được trong **một** call cho mỗi nhóm job (FSO/Customer: `<N*30>` cho ngày ≤12/10 và `<N*60>` cho ngày ≥14/10). Thêm ngày hôm nay chưa trọn thì nối thêm một vế `count_over_time(...[<số giờ>h]) >= <N*60>` không có `@`.

**Vì sao không dùng `[Dd:1d]`** (phát hiện 16/10/2026): điểm eval của subquery align theo **bội số epoch của step**, tức nửa đêm **UTC = 07:00 ICT**, chứ không theo mốc `time` của query. Kiểm bằng `max_over_time(timestamp(vector(1))[4d:1d])` tại `2026-10-16T00:00:00+07:00` → ra `1792022400` = 15/10 07:00 ICT (và `min_over_time` ra 12/10 07:00 ICT). Hậu quả: cửa sổ bị trượt 7 giờ, **mất hẳn giờ làm việc của ngày cuối** và dính thêm phần ngày trước ngày đầu. Triệu chứng nhận ra lỗi: dòng gộp NHỎ hơn một ô ngày lẻ (16/10 thấy Customer gộp 1 < ngày 15/10 là 2, FSO gộp 125 so với 124 của union đúng). `offset` không chữa được vì alignment vẫn theo epoch.

`@ <epoch>` đã kiểm là hoạt động trên VM này và tái tạo đúng y số của instant query cùng mốc (15/10: 415/26/98/2).

Ghi chú kỹ thuật:
- `topk by (vmid) (1, ...)` ép 1 series/vmid (info trùng series khi `ip`/`owner`/`pool` đổi trong ngày) — bắt buộc để `group_left` không lỗi duplicate.
- KHÔNG bọc `count by (owner, …)`: tử số đếm máy, xem mục Định nghĩa.
- `session_name` hiện 1:1 với vmid; nếu nghi ngờ, check `count(count by (vmid)(...))` vs `count(count by (vmid, session_name)(...))`.
- Đừng gộp hai phép đếm bằng `or` để tiết kiệm call: `count(A) or count(B)` chỉ trả vế đầu khi nó khác rỗng (hai vế cùng label set rỗng) ⇒ tưởng đo 2 số mà thực ra chỉ có 1. Chạy tách thành 2 query.

### 2. Mẫu số — TỔNG MÁY đã cấp phát (mặc định)

Nguồn chuẩn = **service discovery của windows-exporter**: mỗi target là 1 VD đã cấp phát và target CÓ sẵn label `vmid`, nên join thẳng với info để tách broker/project. Instant query, cùng `time` với query 1:

```promql
count by (instance, fim) (
  up{job=~".*windows-exporter-scrape.*", vmid!=""}
  * on(vmid) group_left(instance, fim)
    label_replace(topk by (vmid) (1, <INFO_JOIN>),
                  "fim", "FIM", "project_id", "edee0969aeab41e8b1cef7229086eb98")
)
```

Đặt `vmid!=""` ngay trong query để loại máy template (xem 2c) — mẫu số đúng luôn, không phải trừ tay sau. Cần breakdown project thì đổi `fim` → `project_id` y như query 1.

- Ba job tương ứng ba broker: `scrapeConfig/fcd-monitor/windows-exporter-scrape` (broker fci = FCI + FIM), `…-scrape-fso`, `…-scrape-customer`. Tổng thô không cần join: `count by (job) (up{job=~".*windows-exporter-scrape.*"})`.
- **SD là nguồn DUY NHẤT của mẫu số** (chốt với user 12/10/2026). KHÔNG lấy và cũng không đối chiếu với pool counter của broker (`fcd_pool_userservice_assigned_count` / `cached_count`): nó đếm theo **row** userservice nên luôn nhiều hơn SD đúng 5 ở FSO (bản ghi Troubleshoot trên máy template, nhiều row một máy), và trộn hai nguồn chỉ sinh ra tranh luận "số nào đúng" chứ không thêm thông tin.
- Máy **đang bật** = thêm `== 1`, **đang tắt** = `== 0`. Mẫu số báo cáo dùng TỔNG, không lọc `up`.
- `up` là instant nên đọc được ở mọi mốc quá khứ; lookback mặc định 5m là đủ.

**Mẫu số phải đọc TẠI ĐÚNG MỐC `time` của tử số — không dùng lại con số của tuần trước** (bài học 12/10/2026). Đội máy FSO phình/xẹp hàng chục máy trong một ngày vì team tạo/xoá pool cache; `count(up{job=~".*scrape-fso.*"})` đo tại 00:00 mỗi ngày:

| 22/09 | 23/09 | 25–28/09 | 29/09 | **30/09** | **01/10** | 02/10 | 03–05/10 | 06–09/10 | 10/10 | 11–12/10 |
|---|---|---|---|---|---|---|---|---|---|---|
| 446 | 426 | 439 | 440 | **478** | **479** | 463 | 441 | 445 | 447 | 429 |

Biên độ 53 máy trong 20 ngày. Nếu user nói "FSO phải là 474" thì đó là ô mẫu số của **ngày Tư 30/09**, đo tại mốc eval 01/10 00:00 (479 − 5 template) — xem bảng số đo cuối skill. Không phải giá trị hiện hành, và không phải lý do để sửa query.

Snapshot 12/10/2026 (đã trừ template): **FCI 929 · FIM 76 · FSO 424 · Customer 18 · tổng 1447 VD**. Để so sánh: 21/09 là FCI 934 · FIM 76 · FSO 448 · Customer 20.

#### 2b. Các mẫu số phụ (chỉ đưa khi user hỏi thêm)

Tất cả đều dẫn xuất từ SD + `fcd_user_service_info`, không dùng pool counter:

| Cần gì | Query | Đo 12/10/2026 |
|---|---|---|
| Máy đã gán cho user | `count by (instance) (up{job=~".*windows-exporter-scrape.*", vmid!=""} * on(vmid) group_left(instance) topk by (vmid) (1, last_over_time(fcd_user_service_info{owner!="None"}[24h])))` | fci broker 938, FSO 275, cust 12 |
| Máy còn trong pool, chưa gán | như trên, đổi thành `owner="None"` | fci broker 67, FSO 149, cust 6 |
| Số user thật (distinct owner) | `count by (instance, project_id) (count by (owner, instance, project_id) (topk by (vmid) (1, last_over_time(fcd_user_service_info{owner!="None"}[24h]))))` | |

Tổng hai dòng đầu có thể lệch mẫu số vài máy (12/10: fci 938+67 = 1005 so với 1001 target) vì một `vmid` đổi owner `None`→user trong cửa sổ 24h sẽ rơi vào cả hai nhóm — `topk by (vmid)` chạy sau bộ lọc `owner` nên không gộp được. Lệch vài máy thì bỏ qua, đừng đi vá.

**Bẫy `owner="None"`:** VD nằm trong pool cache (đã tạo, chưa gán cho ai) VẪN có bản ghi `fcd_user_service_info` với `owner="None"` (12/10: FSO 149, fci broker 67, customer 6). Vì vậy `count by (owner)` không lọc sẽ cộng thêm đúng 1 "user" giả mỗi cụm. `owner` còn bị nối đuôi authenticator (`…@fpt.com@fpt.com` ở FSO, `…@FPT-COM-AZURE` ở FCI) — không tách, chỉ dùng để dedupe. Điều này KHÔNG ảnh hưởng tử số (máy trong pool không có phiên RDP).

#### 2c. Trùng IP và máy template trong mẫu số (kiểm 02/10/2026)

Mẫu số **phải là số máy riêng biệt theo IP**. Tin tốt: mẫu số lấy từ SD target **đã tự distinct theo IP rồi** — mỗi target là một `instance` = `IP:9182` duy nhất. Kiểm ở 5 mốc trong tuần 28/09–02/10 đều ra `count(up{...})` == `count(count by (instance) (up{...}))` (1483/1521/1468/1454/1448) và không có target nào IP rỗng (`instance=":9182"`). Không cần bọc thêm `count by (instance)`, nhưng nếu muốn chắc thì:

```promql
count(count by (instance) (up{job=~".*windows-exporter-scrape.*"}))
```

Chỗ **thật sự** có nhiều bản ghi trùng một IP là `fcd_user_service_info`, và cả hai loại đều KHÔNG lọt vào mẫu số SD:

1. **Bản ghi Troubleshoot trên máy template, không có label `vmid`**, tên đặt theo `<IP>:1`, `<IP>:2`, `<IP>:3`, owner `<user>@Troubleshoot` — mỗi phiên troubleshoot một bản ghi trên cùng một máy. Ví dụ 02/10: `169.230.104.230` có 3 bản ghi, `169.230.102.162` / `169.230.104.167` / `169.230.104.239` mỗi IP 2 bản ghi, đều pool `Template FSOFT …`.
2. **Cùng `vmid`, nhãn đổi trong cửa sổ 24h** (owner `None`→user, hoặc pool đổi): 02/10 có `VPBankSFCD-1h97`, `CVP00169733A`, `HL-MINHTN51`. `topk by (vmid) (1, …)` đã gộp sẵn.

**Việc cần làm với mẫu số là trừ máy template, không phải dedup IP.** Target không có `vmid` chính là máy template đó — ổn định 5 FSO + 1 Customer suốt tuần 28/09–02/10:

```promql
count by (job) (up{job=~".*windows-exporter-scrape.*", vmid=""})
```

Query mẫu số ở mục 2 đã có `vmid!=""` nên loại sẵn nhóm này; tỷ lệ chỉ nhích 0,1–0,3 điểm phần trăm nên không đổi kết luận, nhưng là con số đúng. Số máy template ổn định **5 FSO + 1 Customer**, broker fci không có (kiểm lại 12/10/2026).

**Trùng TÊN máy thì giữ cả hai** — là máy thật, chỉ clone trùng hostname Windows: 02/10 có `HL-HIEUND93` (HieuND93 có 2 VD ở pool AI-DEV-Win11 và AI-INTERN-Win11, 2 IP khác nhau) và `TEST-002` (2 VD ở 2 project). Tử số đếm theo `vmid` nên hai máy này vào mẫu số và tử số như hai máy riêng, đúng ý. Tìm bằng:

```promql
count by (name) (up{job=~".*windows-exporter-scrape.*"} * on(vmid) group_left(name) topk by (vmid) (1, last_over_time(fcd_user_service_info[24h]))) > 1
```

### 3. Verify không sót (bắt buộc chạy ít nhất 1 ngày đại diện)

VD active theo RemoteFX nhưng **không có bản ghi `fcd_user_service_info` nào** — kỳ vọng **rỗng**. Vì `<INFO_JOIN>` giờ không lọc project, kết quả khác rỗng nghĩa là VD chưa đăng ký với broker nào (hoặc bản ghi info thiếu label `vmid`), chứ không còn là lỗi mapping cũ:

```promql
count(
  (sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[24h])) >= <N*60>)
  unless on(vmid) <INFO_JOIN>
)
```

### 4. Danh sách máy KHÔNG active trong một khoảng thời gian

Câu hỏi hay đi kèm báo cáo active: máy nào cấp rồi mà bỏ không. Định nghĩa dùng ở đây là **không có một mẫu RemoteFX nào** trong cửa sổ, tức là chưa từng mở phiên RDP lần nào.

**4a. Danh sách máy im lặng suốt cửa sổ.** Đổi `[7d]` theo nhu cầu:

```promql
topk by (vmid) (1, last_over_time(fcd_user_service_info[24h]))
  unless on(vmid)
(sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[7d])))
```

Kết quả trả về nguyên các nhãn của `fcd_user_service_info`, đủ để đọc thẳng: `name` là tên máy, kèm `ip`, `owner`, `pool`, `project_id`, `instance`. Muốn đếm theo cụm thì bọc thêm `count by (instance, project_id) (…)`.

Ở đây **không lọc `owner`**, nhất quán với quy ước mẫu số là tổng máy. Máy đang nằm trong pool chưa gán cho ai sẽ hiện ra với `owner="None"` — đó là tài nguyên đã tạo mà chưa ai dùng, vẫn tính là không active. Muốn tách riêng phần đã gán thì mới thêm `{owner!="None"}`.

**4b. Xếp hạng theo số ngày kể từ lần cuối có phiên.** Hữu ích hơn khi cần chọn máy để thu hồi:

```promql
round(
  (time() - max by (vmid) (
     last_over_time(timestamp(windows_remote_fx_net_current_tcp_rtt_seconds)[30d:1h])
  )) / 86400, 0.1)
* on(vmid) group_left(name, owner, ip, pool, project_id, instance)
  topk by (vmid) (1, last_over_time(fcd_user_service_info[24h]))
```

Giá trị trả về là số ngày. Bọc `topk(20, …)` để lấy nhóm lâu nhất.

Hai câu này bù nhau chứ không thay nhau: 4b chỉ thấy được máy có ít nhất một mẫu trong cửa sổ subquery, máy im lặng hoàn toàn sẽ không xuất hiện. Muốn danh sách đầy đủ thì lấy 4a trước rồi dùng 4b để xếp hạng phần còn lại.

**4c. Không có LƯU LƯỢNG nào,** chặt hơn 4a. Bắt được cả máy có phiên mở nhưng ngồi không, vì 4a chỉ xét sự hiện diện của metric:

```promql
topk by (vmid) (1, last_over_time(fcd_user_service_info{project_id="$project_id"}[24h]))
  unless on(vmid)
(max_over_time(
   (sum by (vmid) (
      rate(windows_remote_fx_net_sent_bytes_total[5m])
    + rate(windows_remote_fx_net_received_bytes_total[5m])
   ))[$__range:5m]
 ) > 0)
```

Viết theo lối "toàn bộ máy TRỪ máy từng có lưu lượng dương". Đừng viết theo lối `rate(...) default -1` rồi so `== -2`: `default` chỉ vá lỗ hổng trong series đã tồn tại, nó KHÔNG sinh ra series cho `vmid` chưa từng có metric. Mà đó đúng là nhóm máy cần tìm, nên câu hỏi tự loại mất đáp án và thường trả về rỗng. Kiểm chứng 22/09: dạng `default -1` ra 0 máy, dạng `unless` ra 4 máy trên cùng project và cùng cửa sổ.

Cửa sổ `rate` phải từ `[5m]` trở lên. Ở 60s/mẫu thì `[1m]` chỉ chứa đúng 1 mẫu nên `rate` không tính được; số đo hồi FSO còn 2 phút/mẫu: `[1m]` ra 50 series so với `[5m]` ra 99, tức mất một nửa cụm FSO.

**Lọc theo project.** Bộ lọc chỉ đặt vào `fcd_user_service_info`, KHÔNG đặt vào metric RemoteFX — RemoteFX không có nhãn `project_id`, thêm vào là query trả về rỗng. Vế `unless` cố ý giữ nguyên toàn bộ fleet: nó chỉ dùng để loại những `vmid` đã có phiên, nên không cần và không được lọc.

```promql
topk by (vmid) (1, last_over_time(fcd_user_service_info{project_id="$project_id"}[24h]))
  unless on(vmid)
(sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[$__range])))
```

Biến Grafana nhiều giá trị thì đổi sang regex: `project_id=~"$project_id"`. Nếu project đó nằm trên nhiều broker (`268dbeb2…` và `1cf677a8…` có trên 2–3 broker) thì thêm cả `instance="$broker"` cho khỏi lẫn.

Về chi phí: subquery `[30d:1h]` ở 4b quét nặng, đo được khoảng 16 giây. Lọc `project_id` làm nhẹ đi rõ rệt.

Số đo 22/09/2026, cửa sổ 7 ngày, không lọc owner (máy không có phiên nào / tổng máy): FCI 340/943, FIM 29/76, FSO 283/447, Customer 18/24. Toàn hệ thống 670/1490, tức 45%. Nếu chỉ tính máy đã gán cho user thì lần lượt là FCI 283, FIM 26, FSO 134, Customer 12 — phần chênh chính là máy nằm trong pool.

## Trình bày kết quả

Bảng: hàng = ngày, cột = FCI / FIM / FSO / Customer, mỗi ô `VD active / TỔNG MÁY (tỷ lệ %)`. Kèm:
- Ghi chú định nghĩa active + ngưỡng + ngày chưa trọn (nếu có).
- Cả hai số đều là **máy**, nên tỷ lệ đọc được trực tiếp là "% đội máy được dùng ≥N giờ".
- Một dòng gộp cả tuần (VD chạm mốc ở ít nhất 1 ngày) — số này luôn cao hơn từng ngày và là con số đáng nhớ nhất.
- Breakdown project cho cụm FCI nếu user cần chi tiết.
- Nếu user yêu cầu danh sách cụ thể: bỏ `count` ngoài cùng, giữ `group_left(name, owner, ip, pool, project_id, instance)` để lấy nhãn máy.

Số đo, ngưỡng 4h, mẫu số đã trừ máy template (VD active / tổng máy). Mẫu số đọc tại đúng mốc eval của từng ngày nên nó nhảy theo ngày — đó là bình thường, xem mục 2.

Tuần 12–16/10/2026 (đo 16/10 lúc 14:03 ICT; 12–13/10 FSO/Customer còn ngưỡng 120 mẫu):

| Ngày | FCI | FIM | FSO | Customer |
|---|---|---|---|---|
| Hai 12/10 | 444 / 926 | 31 / 76 | 98 / 421 | 0 / 18 |
| Ba 13/10 | 427 / 906 | 33 / 76 | 106 / 424 | 0 / 18 |
| Tư 14/10 | 432 / 906 | 27 / 76 | 106 / 469 | 0 / 18 |
| Năm 15/10 | 415 / 905 | 26 / 76 | 98 / 471 | 2 / 20 |
| Sáu 16/10 đến 14:03 | 295 / 905 | 15 / 76 | 72 / 472 | 0 / 19 |
| **Gộp Hai–Năm** | **503 / 905** | **38 / 76** | **124 / 471** | **2 / 20** |

Mốc so sánh cùng giờ: Sáu 09/10 lúc 14:03 là FCI 304 / FIM 7 / FSO 76, chốt ngày thành 425 / 27 / 96 ⇒ 14:03 đạt ~72 % số cuối ngày ở FCI, ~79 % ở FSO (16:00 là ~90 %).

Ngày 15/10 có 2 VD Customer chạm 4h (`VPBankSFCD-4227`, `VD01`) — lần đầu cột này khác 0 kể từ 28/09.

Tuần 05–11/10/2026 (7 ngày trọn, đo lại 12/10):

| Ngày | FCI | FIM | FSO | Customer |
|---|---|---|---|---|
| Hai 05/10 | 436 / 918 | 28 / 76 | 109 / 440 | 0 / 16 |
| Ba 06/10 | 437 / 920 | 32 / 76 | 109 / 440 | 0 / 16 |
| Tư 07/10 | 433 / 925 | 30 / 76 | 110 / 440 | 0 / 17 |
| Năm 08/10 | 429 / 924 | 32 / 76 | 108 / 440 | 0 / 18 |
| Sáu 09/10 | 425 / 922 | 27 / 76 | 96 / 442 | 0 / 18 |
| Bảy 10/10 | 83 / 922 | 2 / 76 | 2 / 424 | 0 / 18 |
| CN 11/10 | 68 / 922 | 1 / 76 | 2 / 424 | 0 / 18 |
| **Gộp 7 ngày** | **512 / 922** | **40 / 76** | **133 / 424** | **0 / 18** |

**Hình dạng một tuần bình thường** (dùng để sanity-check kết quả lạ): T2–T5 là plateau (FCI 429–437, FSO 108–110), **Thứ Sáu tụt nhẹ và tụt ở FSO nhiều hơn FCI** (FSO −11% còn 96, FCI chỉ −1%), **cuối tuần gần như tắt** (FCI 83 rồi 68 = 7–9%, FIM 2 rồi 1, FSO đúng 2 máy). Gộp 7 ngày cao hơn ngày cao nhất khoảng +17% ở FCI và +21% ở FSO.

Đối chiếu cách đo ngày chưa trọn: Sáu 09/10 đo lúc 16:00 (cửa sổ `[960m]`) ra FCI 382, FIM 19, FSO 90; trọn ngày thành 425 / 27 / 96 — tức lúc 16:00 đã đạt ~90% con số cuối ngày, dùng để báo sớm được.

Tuần 28/09–02/10/2026:

| Ngày | FCI | FIM | FSO | Customer |
|---|---|---|---|---|
| Hai 28/09 | 430 / 947 | 29 / 76 | 93 / 435 | 1 / 19 |
| Ba 29/09 | 424 / 947 | 31 / 76 | 79 / 473 | 0 / 19 |
| Tư 30/09 | 416 / 895 | 31 / 76 | 88 / 474 | 0 / 17 |
| Năm 01/10 | 428 / 897 | 27 / 76 | 106 / 458 | 0 / 17 |
| Gộp Hai–Năm | 482 / 947 | 34 / 76 | 108 / 458 | 1 / 17 |

FCI rất đều, 45–48% các ngày trong tuần suốt hai tuần. FSO nhích từ 17–23% (tuần 28/09) lên 24–25% (tuần 05/10). Customer gần như không dùng: tuần 05–09/10 có 4 VD **có** phiên RDP nhưng 0 máy nào chạm 4h/ngày — khi báo 0 thì kiểm lại bằng ngưỡng `>= 1` để chắc đó không phải lỗi join:

```promql
count by (instance) ((sum by (vmid) (count_over_time(windows_remote_fx_net_current_tcp_rtt_seconds[4d])) >= 1)
  * on(vmid) group_left(instance) topk by (vmid) (1, last_over_time(fcd_user_service_info{instance="customer.fcd.fptcloud.com:443"}[24h])))
```

## Dashboard Grafana (thêm 21/10/2026)

Cùng logic này đã được dựng thành dashboard **FCD Active Users** (uid `fcd-active-users`) trong gitops `k8s/fcd-monitor/manifests/base/dashboard/fcd-active-users.yml`. Biến: **Cụm** (FPT = FCI+FIM / FSO / Customer, All), **Project** (tên tra từ `fcd_service_project_metadata`, giá trị = project_id, lọc theo cụm), **Ngưỡng giờ** (1–12h, mặc định 4), và time range của Grafana (mặc định `now/w` → `now`). Kết quả vẫn tách FCI và FIM thành hai dòng. Khi user chỉ cần xem nhanh thì chỉ họ vào dashboard; skill này là nguồn để đối chiếu số.

**Mẹo căn ngày theo giờ VN trong range query Grafana** (không dùng được `@` vì không biết trước số ngày, không dùng được `[Dd:1d]` vì lệch 7h, và step `1d` thì Grafana + VM đều căn về nửa đêm UTC nên mất luôn ngày hôm nay): chạy range query với **step 1h**, chỉ giữ điểm **01:00 ICT** mỗi ngày bằng `and on () (hour() == 18)`, và dùng cửa sổ **`[24h] offset -23h`** — tại 01:00 ngày D cửa sổ này phủ đúng `(00:00 D, 24:00 D]`, ngày hôm nay thành ngày chưa trọn một cách tự nhiên. Gộp cả kỳ = `max_over_time((<daily_vd>)[${__range_s}s:1h])`; số ngày đạt ngưỡng của từng VD = `count_over_time(...)` cùng subquery (điểm 01:00 nằm trong `(from, to]` nên range bắt đầu đúng 00:00 vẫn ăn). Mẫu số theo ngày = `last_over_time(up[1h] offset -23h)` (giờ cuối ngày, khớp định nghĩa mục 2) `or` `last_over_time(up[24h] offset -23h)` để ngày chưa trọn có số. Đã đối chiếu 13–17/10/2026 với instant query `@` của skill: trùng 100% (15/10: 415/26/98/2; gộp 14–17/10: 479/33/128/2; mẫu số 14/10: 906/76/469/18). Ngưỡng trong dashboard là `N × 60` cho mọi cụm, nên các ngày ≤ 12/10/2026 FSO/Customer bị đếm theo ngưỡng gấp đôi — đã ghi chú ngay trên dashboard.
